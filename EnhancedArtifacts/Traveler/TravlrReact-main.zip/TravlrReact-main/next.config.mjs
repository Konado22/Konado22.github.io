/** @type {import('next').NextConfig} */
const nextConfig = {
    //basePath:'/travlr-react.vercel.app'
    
};

export default nextConfig;
